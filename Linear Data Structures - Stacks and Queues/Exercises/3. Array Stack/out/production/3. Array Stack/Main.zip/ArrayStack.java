import java.util.Arrays;

public class ArrayStack<T> {

    private static final int INITIAL_CAPACITY = 16;

    private T[] elements;
    private int size;

    public ArrayStack() {
        this.elements = (T[]) new Object[INITIAL_CAPACITY];
        this.size = 0;
    }

    public ArrayStack(int capacity) {
        this.elements = (T[]) new Object[capacity];
        this.size = 0;
    }

    public int size() {
        return this.size;
    }

    private void setSize(int size) {
        this.size = size;
    }

    public void push(T element) {
        if (isFull()) {
            grow();
        }
        this.elements[this.size++] = element;
    }

    public T pop() {
        if (this.size == 0) {
            throw new IllegalArgumentException("The stack is empty");
        }
        T element = this.elements[--this.size];
        this.elements[this.size] = null;
        return element;
    }

    public T[] toArray() {
        return Arrays.copyOf(this.elements, this.size);
    }

    private void grow() {
        this.elements = Arrays.copyOf(this.elements, this.elements.length * 2);
    }

    private boolean isFull() {
        return this.size == this.elements.length;
    }

}