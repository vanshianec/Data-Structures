import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader consoleReader = new BufferedReader(new InputStreamReader(System.in));
        String sentence = consoleReader.readLine();
        HashTable<String, Integer> occurrences = new HashTable<>();
        Arrays.stream(sentence.split("")).forEach(symbol -> {
            if (!occurrences.containsKey(symbol)) {
                occurrences.add(symbol, 0);
            }
            occurrences.addOrReplace(symbol, occurrences.get(symbol) + 1);
        });
        for (KeyValue<String, Integer> occurrence : occurrences) {
            System.out.printf("%s : %d time/s%n", occurrence.getKey(), occurrence.getValue());
        }
    }
}
